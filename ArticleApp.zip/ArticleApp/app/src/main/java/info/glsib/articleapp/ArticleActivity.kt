package info.glsib.articleapp

class ArticleActivity {
}