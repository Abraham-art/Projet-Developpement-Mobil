package info.glsib.articleapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class MainActivity : AppCompatActivity() {

    lateinit var recyclerviewArticle: RecyclerView
    //lateinit var articleArrayList : ArrayList<Article>
    //lateinit var titre : Array<String>
    //lateinit var contenu : Array<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val button = findViewById<Button>(R.id.floatingActionButton3)
        button.setOnClickListener{
            val intent = Intent(this,ArticleAdapter::class.java)
            startActivity(intent)

        }

        recyclerviewArticle = findViewById(R.id.recyclerviewArticle)

        val items = listOf(

           Article( "Intelligence Artificielle", "Ensemble de théories et de techniques mises en œuvre en vue de réaliser des machines capables de simuler l'intelligence humaine.\n" +
                   "\n" +
                   "Avec l'intelligence artificielle, l'homme côtoie un de ses rêves prométhéens les plus ambitieux : fabriquer des machines dotées d'un « esprit » semblable au sien. Pour John MacCarthy, l'un des créateurs de ce concept, « toute activité intellectuelle peut être décrite avec suffisamment de précision pour être simulée par une machine ». Tel est le pari – au demeurant très controversé au sein même de la discipline – de ces chercheurs à la croisée de l'informatique, de l'électronique et des sciences cognitives.\n" +
                   "\n" +
                   "Malgré les débats fondamentaux qu'elle suscite, l'intelligence artificielle a produit nombre de réalisations spectaculaires, par exemple dans les domaines de la reconnaissance des formes ou de la voix, de l'aide à la décision ou de la robotique." ),
           Article( "Cuisine sénégalaise","La cuisine sénégalaise est souvent décrite comme l'une des plus riches et la plus variée d'Afrique de l'Ouest. Elle présente un certain nombre de similitudes avec celles des autres pays de cette région, mais elle a également subi d'autres influences : Afrique du Nord, France ou Portugal.\n" +
                   "\n" +
                   "Relativement peu connue en Europe en dehors des communautés issues de l'immigration et de quelques restaurants de grandes villes, elle a attiré l'attention des médias en 2004 au moment de la publication du livre de Youssou N'Dour, La Cuisine de ma mère1. Le même auteur publiera en 2011 un nouveau livre intitulé \"Sénégal - Cuisine intime et gourmande2\"\n" +
                   "\n" +
                   "Deux ans plus tôt, dans Un grain de vie et d'espérance, la romancière Aminata Sow Fall avait mis en scène la place essentielle occupée par la cuisine dans la culture et la vie quotidienne au Sénégal. Joséphine Ndiaye Haas a écrit un livre « Cuisine sénégalaise » paru aux Éditions L'Harmattan."),

            Article("Les enfants et les jeux vidéo",  "De nos jours, les jeux vidéo font partie de l’univers des enfants, souvent dès leur plus jeune âge. Les enfants ont accès à ces jeux sur différentes plateformes : l’ordinateur, les consoles de jeux, mais aussi les tablettes et les téléphones portables. Il est alors important d’en encadrer l’usage, car certains jeux vidéo peuvent comporter des risques. Toutefois, ces jeux peuvent aussi contribuer à l’apprentissage et au développement des habiletés des enfants. C’est pourquoi il n’est pas nécessaire de les interdire."),

            Article("Sport","Meilleure joueuse de l’équipe de France depuis plusieurs années, Kadi Diani, en fin de contrat au PSG, pourrait faire le choix fracassant de rejoindre… l’OL ! Un sujet qui pourrait faire parler durant la Coupe du monde des Bleues d’Hervé Renard.\n" +
                    "Cela pourrait être le nouveau grand sujet de l’actualité de l’équipe de France féminine, à l’approche de la Coupe du monde féminine (20 juillet-20 août). Kadidiatou Diani est en fin de contrat au PSG le 30 juin et si les Rouge et Bleu souhaitent évidemment conserver leur attaquante de 28 ans, cette dernière est « ardemment » convoitée par l’OL, comme l’indique Le Parisien lundi."),
            Article("Election présidentielle au Sénégal", "Le 25 février 2024 est la date retenue pour l’élection présidentielle au Sénégal. L’information est contenue dans un décret rendu public le 16 février 2023. La question d’un 3ème mandat pour le président Macky Sall, qui n’a pas encore déclaré sa candidature à ce scrutin, continue d’animer le débat public dans le pays.\n" +
                    "L’élection présidentielle sénégalaise se précise. Selon un décret officiel publié le 16 février 2023 par le ministre de l’Intérieur, Antoine Félix Abdoulaye Diome, le scrutin se tiendra le dimanche 25 février 2024. La situation politique reste animée dans le pays, la question d’un 3ème mandat pour le président Macky Sall alimentant les tensions entre l’opposition et le pouvoir.\n" +
                    "\n" +
                    "Les états-majors sont à pied d’œuvre dans une atmosphère politique plus ou moins tendue au regard du procès du principal opposant Ousmane Sonko du Pastef qui a maille à partir avec la justice. Du côté de la mouvance présidentielle, malgré la volonté de l’opposition d’écarter le président Macky Sall du scrutin, sa coalition est en train d’occuper le terrain politique du pays ainsi que son parti politique de manière fiévreuse face à l’opposition.\n" +
                    "\n" +
                    "Papa Mody SOW, Journaliste \n" +
                    "Pour ce scrutin, l’opposant Ousmane Sonko, troisième à la présidentielle de 2019 avec 15,67% des voix et leader du parti des Patriotes africains du Sénégal pour le travail, l’éthique et la fraternité (Pastef), a annoncé sa candidature. Karim Wade, fils de l’ex-président du Sénégal, Abdoulaye Wade, Malick Gakou, ancien ministre des Sports, Khalifa Sall, ancien maire de Dakar ou encore Aminata Touré, ancienne Première ministre, sont également candidats à ce scrutin. Le calendrier pour la révision exceptionnelle des listes électorales en prélude à cette échéance électorale annoncée le 31 janvier 2023 par le gouvernement sénégalais reste attendu.",
            ),
            Article("Music", "Top Banner\n" +
                    "Top BannerCulture\n" +
                    "Musique : Top 12 des chanteurs qui ont marqué l'année 2022\n" +
                    "Par: Alioune Badara Mané - Seneweb.com | 29 décembre, 2022 à 14:12:55  | Lu 5518 Fois |  17 Commentaires\n" +
                    "Single Post\n" +
                    "Top 12 des chanteurs qui ont marqué l'année 2022\n" +
                    "L'année 2022, qui tire à sa fin, a été très mouvementée sur le plan musical, avec des chanteurs qui ont séduit le grand public à travers des séries de concerts, d'albums et de singles. Certains parmi eux ont beaucoup contribué à l'essor de leur style dans la galaxie musicale sénégalaise et de la sous-région. Seneweb vous propose une sélection d'artistes qui vous ont réjouis avec des titres magnifiques et que nous continuerons d'écouter en 2023.\n" +
                    "\n" +
                    "1) Toujours farouche avec son statut de \"Roi du Mbalax\" le lead vocal du Super Étoile de Dakar, Youssou Ndour, occupe la première place, avec une belle performance musicale durant toute l'année 2022, avec la sortie officielle de deux singles plus un album, sans oublier une distinction reçue en Espagne. Son dernier titre en date, \"Boukiyi\", polarise 282 348 vues en sept jours.\n" +
                    "https://youtu.be/3xcV8O_84Fo.\n" +
                    "\n" +
                    "2) Un autre ténor de la musique, Omar Pène occupe la deuxième place, avec une série de concerts à Dakar et dans le reste du monde, avec son dernier album international intitulé \"Climat\". Omar Pène est l'artiste sénégalais le plus titré en 2022, avec deux distinctions : le prix Charles Chros de l'Académie de Lyon et le prix CEDEAO, sans oublier l'inauguration de la place Omar Pène au sein l'université Cheikh Anta Diop de Dakar. Dans le cadre de ses 50 ans de carrière artistique, l'artiste va animer des concerts aux quatre coins du territoire national.\n" +
                    "https://youtu.be/hIVWRG-reVk\n" +
                    "\n" +
                    "3) La troisième place lui revient, grâce à sa performance musicale et sa notoriété internationale qui ne sont plus à démontrer. C'est le lead vocal du groupe Dandé Léniol El hadj Beydi Baaba Maal qui a aussi marqué l'année 2022 avec sa participation dans \"Black Panther 2\" dont il est l'artiste vedette. Il a fêté en 2022 ses 30 ans de carrière musicale avec des séries de concerts dans sept régions du Sénégal. Son dernier single sorti en août dernier a eu un succès fou.\n" +
                    "https://youtu.be/O3jO88cy9wg"),
            Article("Religion",            "La religion au Sénégal occupe une place importante dans la culture et la vie quotidienne du pays. Le Sénégal est un pays (de près de 18 millions habitants, diaspora non comprise, en 2022) où croyances et traditions se mêlent à la modernité, en syncrétisme.\n" +
                    "\n" +
                    "La population sénégalaise est très majoritairement musulmane (94 %)1. Les chrétiens, principalement catholiques, représentent 5 %. Les croyances traditionnelles sont créditées de 1..2 %, mais sont aussi souvent pratiquées par les croyants d'autres religions.\n" +
                    "\n" +
                    "Le pays est réputé pour sa tolérance religieuse2. Le Sénégal est un pays membre de l'Organisation de la coopération islamique."),
            Article("Faits divers","Un chargement d’environ 8 tonnes de déchets spéciaux dangereux classés EER 160104* a été intercepté au port de Livourne, en route vers le Sénégal.\n" +
                    "\n" +
                    "L’enquête menée par les fonctionnaires de l’Agence des douanes et des monopoles (ADM) de Livourne avec les soldats du Commandement des carabiniers pour la protection de l’environnement et la transition écologique – Unité d’opérations écologiques de Grosseto, coordonnée par le procureur de la République de Livourne.\n" +
                    "\n" +
                    "La charge, moteurs de scooter, accessoires et pièces détachées, il se composait de 49 motos, manifestement hors d’usage car ne roulant plus, retrouvées sans les parties avant, enlevées avec une coupe nette et empilées à l’intérieur du conteneur.\n" +
                    "\n" +
                    "Les motos, issues du circuit de la ferraille, étaient encore complètes avec toutes leurs pièces, y compris celles relatives à la sécurité des véhicules, comme les freins, les disques, les suspensions, les amortisseurs et les cadres.\n" +
                    "\n" +
                    "Les enquêteurs ont expliqué que “La législation de référence pour la mise au rebut des véhicules hors d’usage (décret législatif 209/2003) autorise le commerce de pièces relatives à la sécurité des véhicules uniquement par l’intermédiaire de sujets enregistrés auprès d’entreprises exerçant des activités d’autoréparation “."),

        )


        recyclerviewArticle.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = ArticleAdapter(items as ArrayList<Article>)
        }
        //recyclerviewArticle.setHasFixedSize(true)




    }


}