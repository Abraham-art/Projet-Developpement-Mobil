package info.glsib.articleapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ArticleAdapter(var items: ArrayList<Article>) : RecyclerView.Adapter<ArticleAdapter.ArticleViewHolder>()  {

    private lateinit var mListener: onItemClickListener

    interface   onItemClickListener{
        fun onItemClick(position : Int)
    }
    fun setOnItemClickListener(listener: onItemClickListener){
        mListener = listener
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArticleViewHolder {
       val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_article, parent, false)
        return  ArticleViewHolder(itemView,mListener)
    }

    override fun onBindViewHolder(holder: ArticleViewHolder, position: Int) {

        val article = items[position]
        holder.titre.text = article.titre
        holder.contenu.text = article.contenu

    }

    override fun getItemCount() = items.size


    inner class ArticleViewHolder(itemView: View, listener: onItemClickListener) : RecyclerView.ViewHolder(itemView) {

        var  titre : TextView
        var contenu : TextView


        init {
            titre = itemView.findViewById(R.id.titre)
            contenu  = itemView.findViewById(R.id.contenu)
            itemView.setOnClickListener{
                listener.onItemClick(adapterPosition)
            }


        }

    }

}