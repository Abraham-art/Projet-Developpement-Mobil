package info.glsib.articleapp

 data class Article (
     var titre: String,
     var contenu: String,
 )
